# Fashion DS Catalog

Aplicativo Flutter que documenta e demonstra os componentes do Fashion Design System.

## Funcionalidades

- Página inicial com as seis categorias do Design System.
- Navegação para uma galeria específica de cada categoria.
- Action Button em tamanhos Compact e Full Width.
- Estados Default, Pressed, Focused, Filled, Selected, Unselected e Disabled.
- Componentes interativos: Tab Bar, Category Tabs e Favorite Button.
- Arquitetura separada em `common`, `components` e `screens`.
- Exemplo de ViewModel e Factory no Action Button.

## Executar no FlutLab

1. Acesse [flutlab.io](https://flutlab.io) e escolha a opção para criar/importar um projeto.
2. Selecione o upload de projeto por arquivo `.zip`.
3. Envie `fashion_ds_catalog_flutlab.zip`.
4. Aguarde o FlutLab executar o carregamento das dependências.
5. Clique em **Run** para abrir o Web Preview ou em **Build Project** para gerar uma versão.

O ZIP preparado para o FlutLab possui o `pubspec.yaml` na raiz; não é necessário executar `flutter create`.

## Executar localmente

1. Instale o Flutter 3.24 ou superior.
2. Para adicionar plataformas que ainda não existam, execute:

```bash
flutter create . --platforms=android,ios,web
```

3. Instale as dependências e execute:

```bash
flutter pub get
flutter run
```

## Validar

```bash
flutter analyze
flutter test
```
