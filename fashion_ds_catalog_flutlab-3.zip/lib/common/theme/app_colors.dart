import 'package:flutter/material.dart';

abstract final class AppColors {
  static const background = Color(0xFFFAF8F6);
  static const surface = Color(0xFFFFFFFF);
  static const primary = Color(0xFFD7BFB0);
  static const primaryPressed = Color(0xFFC4A99A);
  static const accent = Color(0xFFFF8FA6);
  static const text = Color(0xFF1E1E1E);
  static const textSecondary = Color(0xFF6F6A67);
  static const border = Color(0xFFE5DDD8);
  static const disabled = Color(0xFFE7E1DD);
}
