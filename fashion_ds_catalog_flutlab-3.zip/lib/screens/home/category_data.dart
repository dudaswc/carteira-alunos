import 'package:flutter/material.dart';

enum CatalogCategory { actions, navigation, inputs, content, selectors, cart }

class CategoryData {
  const CategoryData(this.type, this.title, this.subtitle, this.icon);
  final CatalogCategory type;
  final String title;
  final String subtitle;
  final IconData icon;
}

const catalogCategories = [
  CategoryData(CatalogCategory.actions, 'Actions', 'Buttons e estados de ação', Icons.touch_app_rounded),
  CategoryData(CatalogCategory.navigation, 'Navigation', 'Tab bar e categorias', Icons.navigation_rounded),
  CategoryData(CatalogCategory.inputs, 'Inputs & Filters', 'Busca, filtros e cupom', Icons.tune_rounded),
  CategoryData(CatalogCategory.content, 'Cards & Content', 'Cards e conteúdo de produto', Icons.dashboard_rounded),
  CategoryData(CatalogCategory.selectors, 'Selectors & Controls', 'Cor, tamanho e favorito', Icons.toggle_on_rounded),
  CategoryData(CatalogCategory.cart, 'Cart & Commerce', 'Carrinho e resumo de preço', Icons.shopping_bag_rounded),
];
