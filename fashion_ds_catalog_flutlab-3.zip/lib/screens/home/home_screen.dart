import 'package:flutter/material.dart';
import '../../common/theme/app_colors.dart';
import '../samples/category_screen.dart';
import 'category_data.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Fashion DS', style: TextStyle(fontWeight: FontWeight.w800))),
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Text('Component catalog', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Explore os componentes, variações e estados do Design System.', style: TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 24),
            for (final category in catalogCategories) ...[
              _CategoryCard(category: category),
              const SizedBox(height: 12),
            ],
          ]),
        ),
      );
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({required this.category});
  final CategoryData category;
  @override
  Widget build(BuildContext context) => Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: AppColors.border)),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryScreen(category: category))),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .35), borderRadius: BorderRadius.circular(16)), child: Icon(category.icon, color: AppColors.text)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(category.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)), const SizedBox(height: 3), Text(category.subtitle, style: const TextStyle(color: AppColors.textSecondary))])),
              const Icon(Icons.chevron_right_rounded),
            ]),
          ),
        ),
      );
}
