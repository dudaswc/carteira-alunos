import 'package:flutter/material.dart';
import '../../common/models/component_state.dart';
import '../../common/theme/app_colors.dart';
import '../../common/widgets/sample_section.dart';
import '../../components/action_button/action_button_factory.dart';
import '../../components/cart/cart_components.dart';
import '../../components/content/product_card.dart';
import '../../components/inputs/ds_search_field.dart';
import '../../components/inputs/promo_code_field.dart';
import '../../components/navigation/ds_tab_bar.dart';
import '../../components/selectors/ds_selectors.dart';
import '../home/category_data.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key, required this.category});
  final CategoryData category;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(category.title, style: const TextStyle(fontWeight: FontWeight.w800))),
        body: ListView(padding: const EdgeInsets.all(20), children: _samples(category.type)),
      );

  List<Widget> _samples(CatalogCategory type) => switch (type) {
        CatalogCategory.actions => [_actions()],
        CatalogCategory.navigation => [_navigation()],
        CatalogCategory.inputs => [_search(), const SizedBox(height: 16), _promo()],
        CatalogCategory.content => [_content()],
        CatalogCategory.selectors => [_selectors()],
        CatalogCategory.cart => [_cart()],
      };

  Widget _actions() => SampleSection(
        title: 'Action Button',
        description: 'Compact e full width nos estados Default, Pressed e Disabled.',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (final state in [ComponentState.defaultState, ComponentState.pressed, ComponentState.disabled]) ...[
            Text(state.label, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            ActionButtonFactory.compact(state),
            const SizedBox(height: 12),
            ActionButtonFactory.fullWidth(state),
            const SizedBox(height: 20),
          ],
        ]),
      );

  Widget _navigation() => const Column(children: [
        SampleSection(title: 'Tab Bar', description: 'Toque nos itens para alterar o estado selecionado.', child: DsTabBar()),
        SizedBox(height: 16),
        SampleSection(title: 'Category Tabs', description: 'Categorias com estados selecionado e não selecionado.', child: CategoryTabs()),
      ]);

  Widget _search() => SampleSection(
        title: 'Search Field',
        description: 'Default, Focused, Filled e Disabled.',
        child: Column(children: [
          for (final state in [ComponentState.defaultState, ComponentState.focused, ComponentState.filled, ComponentState.disabled]) ...[
            Align(alignment: Alignment.centerLeft, child: Text(state.label, style: const TextStyle(fontWeight: FontWeight.w600))),
            const SizedBox(height: 8),
            DsSearchField(state: state),
            const SizedBox(height: 16),
          ],
        ]),
      );

  Widget _promo() => const SampleSection(
        title: 'Promo Code Field',
        description: 'Estados habilitado e desabilitado.',
        child: Column(children: [PromoCodeField(), SizedBox(height: 16), PromoCodeField(enabled: false)]),
      );

  Widget _content() => const SampleSection(
        title: 'Product Card',
        description: 'Layouts Portrait e Compact.',
        child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [ProductCard(), SizedBox(width: 20), ProductCard(compact: true)])),
      );

  Widget _selectors() => SampleSection(
        title: 'Selectors & Controls',
        description: 'Selected, Unselected e Disabled.',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Favorite Button', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Row(children: [FavoriteButton(), SizedBox(width: 12), FavoriteButton(disabled: true)]),
          const SizedBox(height: 24),
          const Text('Size Option', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Row(children: [SizeOption(label: 'S', state: ComponentState.selected), SizedBox(width: 10), SizeOption(label: 'M', state: ComponentState.unselected), SizedBox(width: 10), SizeOption(label: 'L', state: ComponentState.disabled)]),
          const SizedBox(height: 24),
          const Text('Color Swatch', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Row(children: [DsColorSwatch(color: AppColors.accent, state: ComponentState.selected), SizedBox(width: 10), DsColorSwatch(color: Colors.orange, state: ComponentState.unselected), SizedBox(width: 10), DsColorSwatch(color: Colors.black, state: ComponentState.disabled)]),
        ]),
      );

  Widget _cart() => const Column(children: [
        SampleSection(title: 'Cart Item', description: 'Item com produto, tamanho, quantidade e exclusão.', child: CartItem()),
        SizedBox(height: 16),
        SampleSection(title: 'Price Summary', description: 'Subtotal, frete e total da sacola.', child: PriceSummary()),
      ]);
}
