import 'package:flutter/material.dart';
import '../../common/models/component_state.dart';
import '../../common/theme/app_colors.dart';

class FavoriteButton extends StatefulWidget {
  const FavoriteButton({super.key, this.disabled = false});
  final bool disabled;
  @override
  State<FavoriteButton> createState() => _FavoriteButtonState();
}

class _FavoriteButtonState extends State<FavoriteButton> {
  bool selected = true;
  @override
  Widget build(BuildContext context) => IconButton.filledTonal(
        onPressed: widget.disabled ? null : () => setState(() => selected = !selected),
        icon: Icon(selected ? Icons.favorite : Icons.favorite_border),
        color: selected ? AppColors.accent : AppColors.textSecondary,
      );
}

class SizeOption extends StatelessWidget {
  const SizeOption({super.key, required this.label, required this.state});
  final String label;
  final ComponentState state;
  @override
  Widget build(BuildContext context) {
    final selected = state == ComponentState.selected;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      width: 44,
      height: 44,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: selected ? AppColors.accent : Colors.white,
        border: selected ? null : Border.all(color: AppColors.border),
      ),
      child: Opacity(opacity: state == ComponentState.disabled ? .3 : 1, child: Text(label, style: TextStyle(color: selected ? Colors.white : AppColors.text, fontWeight: FontWeight.w700))),
    );
  }
}

class DsColorSwatch extends StatelessWidget {
  const DsColorSwatch({super.key, required this.color, required this.state});
  final Color color;
  final ComponentState state;
  @override
  Widget build(BuildContext context) => Opacity(
        opacity: state == ComponentState.disabled ? .3 : 1,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3)),
          child: state == ComponentState.selected ? const Icon(Icons.check, color: Colors.white) : null,
        ),
      );
}
