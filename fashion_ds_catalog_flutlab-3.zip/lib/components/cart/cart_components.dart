import 'package:flutter/material.dart';
import '../../common/theme/app_colors.dart';

class CartItem extends StatelessWidget {
  const CartItem({super.key});
  @override
  Widget build(BuildContext context) => Row(children: [
        Container(width: 72, height: 72, decoration: BoxDecoration(color: const Color(0xFFFFD7DF), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.checkroom)),
        const SizedBox(width: 14),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Modern Style Outfit', style: TextStyle(fontWeight: FontWeight.w700)), Text('R\$ 129,90', style: TextStyle(color: AppColors.textSecondary)), Text('−   1   +')])),
        const Column(children: [Text('L'), SizedBox(height: 20), Icon(Icons.delete_outline, size: 20)]),
      ]);
}

class PriceSummary extends StatelessWidget {
  const PriceSummary({super.key});
  @override
  Widget build(BuildContext context) => const Column(children: [
        _PriceRow('Subtotal', 'R\$ 239,90'),
        _PriceRow('Shipping', 'R\$ 20,00'),
        Divider(),
        _PriceRow('Bag total', 'R\$ 259,90', bold: true),
      ]);
}

class _PriceRow extends StatelessWidget {
  const _PriceRow(this.label, this.value, {this.bold = false});
  final String label;
  final String value;
  final bool bold;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w700 : null)), const Expanded(child: Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Divider())), Text(value, style: TextStyle(fontWeight: bold ? FontWeight.w700 : null))]),
      );
}
