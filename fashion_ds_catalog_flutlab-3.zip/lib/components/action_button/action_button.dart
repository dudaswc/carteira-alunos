import 'package:flutter/material.dart';
import '../../common/models/component_state.dart';
import '../../common/theme/app_colors.dart';
import 'action_button_view_model.dart';

class DsActionButton extends StatelessWidget {
  const DsActionButton({super.key, required this.viewModel, this.onPressed});
  final ActionButtonViewModel viewModel;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final disabled = viewModel.isDisabled;
    final pressed = viewModel.state == ComponentState.pressed;
    final button = SizedBox(
      height: viewModel.size == ActionButtonSize.compact ? 48 : 56,
      width: viewModel.size == ActionButtonSize.compact ? 156 : double.infinity,
      child: FilledButton(
        onPressed: disabled ? null : onPressed ?? () {},
        style: FilledButton.styleFrom(
          backgroundColor: pressed ? AppColors.primaryPressed : AppColors.primary,
          disabledBackgroundColor: AppColors.disabled,
          disabledForegroundColor: AppColors.textSecondary.withValues(alpha: .55),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Text(viewModel.label, style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
    return viewModel.size == ActionButtonSize.fullWidth ? button : Align(alignment: Alignment.centerLeft, child: button);
  }
}
